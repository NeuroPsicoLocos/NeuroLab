# Modelo 3D desde fotos: encefalo desmontable

Este proyecto genera una reconstruccion aproximada, imprimible en 3D, de un encefalo didactico desmontable mostrado en las fotos de `Fotos/`.

La geometria no es una fotogrametria exacta. Es un conjunto parametrico hecho para producir piezas didacticas y reproducibles: hemisferios cerebrales, cerebelo, tronco encefalico, arco vascular simplificado y una seccion anatómica curva de referencia.

## Archivos

- `scripts/generate_brain_section_model.py`: genera el modelo desde cero con Python puro.
- `scripts/generate_modular_encephalon.py`: genera el encefalo desmontable por piezas.
- `models/brain_section_approx.stl`: pieza curva de referencia basada en una de las secciones visibles.
- `models/modular_encephalon/`: STL y OBJ de cada modulo desmontable.
- `Fotos/`: fotografias de referencia.

## Como regenerar los STL

```bash
python3 scripts/generate_modular_encephalon.py
python3 scripts/generate_brain_section_model.py
```

Los scripts no requieren librerias externas.

## Piezas generadas

- `left_cerebral_hemisphere.stl`: hemisferio cerebral izquierdo simplificado.
- `right_cerebral_hemisphere.stl`: hemisferio cerebral derecho simplificado.
- `cerebellum.stl`: cerebelo con folias simplificadas.
- `brainstem.stl`: tronco encefalico simplificado.
- `vascular_arch_simplified.stl`: arco vascular transparente/arterial simplificado.
- `brain_section_approx.stl`: seccion curva con relieve, borde, postes y zona estriada.

## Parametros editables

Dentro de `scripts/generate_brain_section_model.py` puedes ajustar:

- `MODEL_LENGTH_MM`: largo aproximado.
- `MODEL_WIDTH_MM`: ancho aproximado.
- `BASE_THICKNESS_MM`: grosor minimo.
- `RELIEF_SCALE_MM`: altura del relieve superior.
- `PIN_RADIUS_MM` y `PIN_HEIGHT_MM`: postes cilindricos.

En `scripts/generate_modular_encephalon.py` puedes editar dimensiones de cada pieza directamente en las funciones:

- `cerebral_hemisphere()`
- `cerebellum()`
- `brainstem()`
- `vascular_arch()`

## Recomendaciones de impresion

- Material: PLA o PETG.
- Altura de capa: 0.16-0.20 mm.
- Infill: 15-25%.
- Perimetros: 3.
- Orientacion: imprimir con la cara plana inferior sobre la cama.
- Soportes: normalmente no necesarios para esta version, salvo que se escalen mucho los pines laterales.

## Notas de exactitud

Esta reconstruccion es visual y educativa. Para que la pieza encaje con un modelo fisico existente se necesitan al menos:

1. Largo total.
2. Ancho maximo.
3. Grosor de la base.
4. Diametro y separacion entre postes.
5. Diametro y posicion de orificios.

Sin esas medidas, estos STL deben considerarse una primera version para prueba de forma y docencia, no una copia final del modelo desmontable original.

## Anatomia representada

1. Anatomia: hemisferios cerebrales, cerebelo, tronco encefalico y un arco vascular simplificado.
2. Conectividad: los pines/encajes son orientativos para ensamblaje fisico, no representan tractos reales.
3. Funcion: adecuado para docencia basica de organizacion macroscópica del encefalo.
4. Clinica: no usar como atlas clinico ni quirurgico; las circunvoluciones y folias son simplificadas.
5. Bibliografia: no se agregan referencias porque el modelo se deriva de fotos del objeto fisico, no de una fuente anatómica primaria.
