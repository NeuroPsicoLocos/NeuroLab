#!/usr/bin/env python3
"""
Generate an approximate 3D-printable neuroanatomical teaching piece from photos.

The model is intentionally parametric and dependency-free. It creates:
- a curved extruded base with two through-holes,
- a raised outer rim,
- smooth gyrus-like relief,
- an internal striated fan,
- vertical and lateral cylindrical pins.

This is not photogrammetry. It is a clean printable approximation that can be
scaled and tuned once real caliper measurements are available.
"""

from __future__ import annotations

import math
from pathlib import Path


MODEL_LENGTH_MM = 110.0
MODEL_WIDTH_MM = 62.0
BASE_THICKNESS_MM = 4.5
RELIEF_SCALE_MM = 8.0
PIN_RADIUS_MM = 3.1
PIN_HEIGHT_MM = 12.0

GRID_NX = 126
GRID_NY = 76

OUT_DIR = Path("models")
STL_PATH = OUT_DIR / "brain_section_approx.stl"
OBJ_PATH = OUT_DIR / "brain_section_approx.obj"


class Mesh:
    def __init__(self) -> None:
        self.vertices: list[tuple[float, float, float]] = []
        self.faces: list[tuple[int, int, int]] = []

    def add_vertex(self, p: tuple[float, float, float]) -> int:
        self.vertices.append(p)
        return len(self.vertices) - 1

    def add_face(self, a: int, b: int, c: int) -> None:
        self.faces.append((a, b, c))

    def add_quad(self, a: int, b: int, c: int, d: int) -> None:
        self.add_face(a, b, c)
        self.add_face(a, c, d)


def point_in_polygon(x: float, y: float, polygon: list[tuple[float, float]]) -> bool:
    inside = False
    j = len(polygon) - 1
    for i in range(len(polygon)):
        xi, yi = polygon[i]
        xj, yj = polygon[j]
        if ((yi > y) != (yj > y)) and (
            x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-9) + xi
        ):
            inside = not inside
        j = i
    return inside


def height_field(x: float, y: float) -> float:
    """Soft anatomical relief: simplified gyri and central mound."""
    x_norm = x / (MODEL_LENGTH_MM * 0.5)
    y_norm = y / (MODEL_WIDTH_MM * 0.5)
    mound = math.exp(-((x_norm + 0.05) ** 2 * 2.2 + (y_norm + 0.05) ** 2 * 1.4))
    ripples = 0.34 * math.sin(0.23 * x + 1.4 * math.sin(0.13 * y))
    ripples += 0.22 * math.sin(0.35 * y + 0.2 * x)
    posterior_bulge = 0.45 * math.exp(-((x - 28) ** 2 / 900 + (y + 7) ** 2 / 260))
    anterior_bulge = 0.38 * math.exp(-((x + 30) ** 2 / 650 + (y - 2) ** 2 / 320))
    return BASE_THICKNESS_MM + RELIEF_SCALE_MM * max(0.08, mound + posterior_bulge + anterior_bulge + ripples)


def footprint_polygon() -> list[tuple[float, float]]:
    """Approximate crescent-like outline seen in the reference photos."""
    return [
        (-54, -5), (-50, 12), (-40, 24), (-22, 29), (0, 30),
        (24, 28), (44, 19), (54, 5), (51, -14), (37, -22),
        (20, -22), (7, -31), (-11, -27), (-25, -23), (-42, -18),
        (-52, -12),
    ]


HOLES = [
    (-43.0, 7.0, 4.1),
    (42.0, -8.0, 3.8),
]


def in_model(x: float, y: float) -> bool:
    if not point_in_polygon(x, y, footprint_polygon()):
        return False
    for hx, hy, hr in HOLES:
        if (x - hx) ** 2 + (y - hy) ** 2 < hr ** 2:
            return False
    return True


def add_base(mesh: Mesh) -> None:
    x_min, x_max = -MODEL_LENGTH_MM / 2, MODEL_LENGTH_MM / 2
    y_min, y_max = -MODEL_WIDTH_MM / 2, MODEL_WIDTH_MM / 2
    dx = (x_max - x_min) / (GRID_NX - 1)
    dy = (y_max - y_min) / (GRID_NY - 1)

    top: dict[tuple[int, int], int] = {}
    bottom: dict[tuple[int, int], int] = {}

    for ix in range(GRID_NX):
        for iy in range(GRID_NY):
            x = x_min + ix * dx
            y = y_min + iy * dy
            if in_model(x, y):
                top[(ix, iy)] = mesh.add_vertex((x, y, height_field(x, y)))
                bottom[(ix, iy)] = mesh.add_vertex((x, y, 0.0))

    for ix in range(GRID_NX - 1):
        for iy in range(GRID_NY - 1):
            corners = [(ix, iy), (ix + 1, iy), (ix + 1, iy + 1), (ix, iy + 1)]
            if all(c in top for c in corners):
                a, b, c, d = [top[k] for k in corners]
                mesh.add_quad(a, b, c, d)
                ba, bb, bc, bd = [bottom[k] for k in corners]
                mesh.add_quad(bd, bc, bb, ba)

    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    for key, v_top in list(top.items()):
        ix, iy = key
        for ox, oy in directions:
            nb = (ix + ox, iy + oy)
            if nb not in top:
                x1 = x_min + ix * dx
                y1 = y_min + iy * dy
                x2 = x_min + (ix + (oy != 0)) * dx
                y2 = y_min + (iy + (ox != 0)) * dy
                if ox != 0:
                    p1 = (x1 + ox * dx * 0.5, y1 - dy * 0.5, 0.0)
                    p2 = (x1 + ox * dx * 0.5, y1 + dy * 0.5, 0.0)
                else:
                    p1 = (x1 - dx * 0.5, y1 + oy * dy * 0.5, 0.0)
                    p2 = (x1 + dx * 0.5, y1 + oy * dy * 0.5, 0.0)
                mid1 = mesh.add_vertex(p1)
                mid2 = mesh.add_vertex(p2)
                p1_top = mesh.add_vertex((p1[0], p1[1], height_field(p1[0], p1[1])))
                p2_top = mesh.add_vertex((p2[0], p2[1], height_field(p2[0], p2[1])))
                mesh.add_quad(mid1, mid2, p2_top, p1_top)


def basis_from_axis(axis: tuple[float, float, float]) -> tuple[tuple[float, float, float], tuple[float, float, float]]:
    ax, ay, az = axis
    length = math.sqrt(ax * ax + ay * ay + az * az)
    ux, uy, uz = ax / length, ay / length, az / length
    helper = (0.0, 0.0, 1.0) if abs(uz) < 0.9 else (1.0, 0.0, 0.0)
    vx = uy * helper[2] - uz * helper[1]
    vy = uz * helper[0] - ux * helper[2]
    vz = ux * helper[1] - uy * helper[0]
    vlen = math.sqrt(vx * vx + vy * vy + vz * vz)
    vx, vy, vz = vx / vlen, vy / vlen, vz / vlen
    wx = uy * vz - uz * vy
    wy = uz * vx - ux * vz
    wz = ux * vy - uy * vx
    return (vx, vy, vz), (wx, wy, wz)


def add_cylinder_between(
    mesh: Mesh,
    p0: tuple[float, float, float],
    p1: tuple[float, float, float],
    radius: float,
    segments: int = 32,
) -> None:
    axis = (p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2])
    v, w = basis_from_axis(axis)
    ring0, ring1 = [], []
    for i in range(segments):
        ang = 2 * math.pi * i / segments
        ca, sa = math.cos(ang), math.sin(ang)
        offset = (
            radius * (ca * v[0] + sa * w[0]),
            radius * (ca * v[1] + sa * w[1]),
            radius * (ca * v[2] + sa * w[2]),
        )
        ring0.append(mesh.add_vertex((p0[0] + offset[0], p0[1] + offset[1], p0[2] + offset[2])))
        ring1.append(mesh.add_vertex((p1[0] + offset[0], p1[1] + offset[1], p1[2] + offset[2])))
    c0 = mesh.add_vertex(p0)
    c1 = mesh.add_vertex(p1)
    for i in range(segments):
        j = (i + 1) % segments
        mesh.add_quad(ring0[i], ring0[j], ring1[j], ring1[i])
        mesh.add_face(c0, ring0[j], ring0[i])
        mesh.add_face(c1, ring1[i], ring1[j])


def add_vertical_annular_cylinder(
    mesh: Mesh,
    center: tuple[float, float, float],
    inner_radius: float,
    outer_radius: float,
    height: float,
    segments: int = 36,
) -> None:
    cx, cy, cz = center
    rings: dict[str, list[int]] = {"ob": [], "ot": [], "ib": [], "it": []}
    for i in range(segments):
        ang = 2 * math.pi * i / segments
        ca, sa = math.cos(ang), math.sin(ang)
        rings["ob"].append(mesh.add_vertex((cx + outer_radius * ca, cy + outer_radius * sa, cz)))
        rings["ot"].append(mesh.add_vertex((cx + outer_radius * ca, cy + outer_radius * sa, cz + height)))
        rings["ib"].append(mesh.add_vertex((cx + inner_radius * ca, cy + inner_radius * sa, cz)))
        rings["it"].append(mesh.add_vertex((cx + inner_radius * ca, cy + inner_radius * sa, cz + height)))

    for i in range(segments):
        j = (i + 1) % segments
        mesh.add_quad(rings["ob"][i], rings["ob"][j], rings["ot"][j], rings["ot"][i])
        mesh.add_quad(rings["ib"][j], rings["ib"][i], rings["it"][i], rings["it"][j])
        mesh.add_quad(rings["ot"][i], rings["ot"][j], rings["it"][j], rings["it"][i])
        mesh.add_quad(rings["ob"][j], rings["ob"][i], rings["ib"][i], rings["ib"][j])


def add_ellipsoid(
    mesh: Mesh,
    center: tuple[float, float, float],
    radii: tuple[float, float, float],
    rot_z: float,
    lat_steps: int = 10,
    lon_steps: int = 28,
) -> None:
    cx, cy, cz = center
    rx, ry, rz = radii
    cr, sr = math.cos(rot_z), math.sin(rot_z)
    grid: list[list[int]] = []
    for ilat in range(lat_steps + 1):
        theta = math.pi * ilat / lat_steps
        row = []
        for ilon in range(lon_steps):
            phi = 2 * math.pi * ilon / lon_steps
            x = rx * math.sin(theta) * math.cos(phi)
            y = ry * math.sin(theta) * math.sin(phi)
            z = rz * math.cos(theta)
            xr = cr * x - sr * y
            yr = sr * x + cr * y
            row.append(mesh.add_vertex((cx + xr, cy + yr, cz + z)))
        grid.append(row)
    for ilat in range(lat_steps):
        for ilon in range(lon_steps):
            j = (ilon + 1) % lon_steps
            mesh.add_quad(grid[ilat][ilon], grid[ilat][j], grid[ilat + 1][j], grid[ilat + 1][ilon])


def add_relief(mesh: Mesh) -> None:
    # Smooth raised gyri, based on the visible superior surface.
    gyri = [
        (-30, 8, 17, 5, 3.4, -0.6), (-13, 15, 18, 5, 3.2, 0.15),
        (9, 17, 19, 5, 3.4, -0.2), (30, 10, 15, 5, 3.0, 0.55),
        (-33, -8, 16, 5, 3.0, 0.4), (-12, -7, 18, 5, 3.2, -0.3),
        (12, -8, 19, 5, 3.2, 0.35), (30, -11, 15, 5, 3.0, -0.45),
        (-4, -21, 15, 4, 2.8, 0.1),
    ]
    for x, y, rx, ry, rz, rot in gyri:
        z = height_field(x, y) + 1.6
        add_ellipsoid(mesh, (x, y, z), (rx, ry, rz), rot)

    # Raised outer rim following the scalloped border.
    poly = footprint_polygon()
    for a, b in zip(poly, poly[1:] + poly[:1]):
        mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
        z = height_field(mx, my) + 1.8
        add_cylinder_between(mesh, (a[0], a[1], z), (b[0], b[1], z), 2.0, 18)

    # Internal striated fan, simplified from the pale ridged region in the photos.
    fan_origin = (-6.0, -16.0, BASE_THICKNESS_MM + 9.5)
    for i in range(28):
        angle = math.radians(28 + i * 4.0)
        length = 31 + 8 * math.sin(i / 27 * math.pi)
        x1 = fan_origin[0] + math.cos(angle) * length
        y1 = fan_origin[1] + math.sin(angle) * length
        z1 = height_field(x1, y1) + 1.8
        add_cylinder_between(mesh, fan_origin, (x1, y1, z1), 0.48, 10)

    # Posts and side pins visible in the references.
    for x, y in [(-36, 16), (40, 11)]:
        z = height_field(x, y)
        add_cylinder_between(mesh, (x, y, z - 0.5), (x, y, z + PIN_HEIGHT_MM), PIN_RADIUS_MM, 32)

    add_cylinder_between(mesh, (-57, -10, 7.5), (-45, -10, 7.5), 2.7, 24)
    add_cylinder_between(mesh, (45, -17, 7.2), (57, -17, 7.2), 2.7, 24)

    # Raised rings around through-holes for print legibility.
    for hx, hy, hr in HOLES:
        z = height_field(hx, hy) + 1.0
        add_vertical_annular_cylinder(mesh, (hx, hy, z - 0.2), hr + 0.15, hr + 1.25, 1.4)


def normal(a: tuple[float, float, float], b: tuple[float, float, float], c: tuple[float, float, float]) -> tuple[float, float, float]:
    ux, uy, uz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
    vx, vy, vz = c[0] - a[0], c[1] - a[1], c[2] - a[2]
    nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
    length = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
    return nx / length, ny / length, nz / length


def write_ascii_stl(mesh: Mesh, path: Path) -> None:
    with path.open("w", encoding="ascii") as f:
        f.write("solid brain_section_approx\n")
        for ia, ib, ic in mesh.faces:
            a, b, c = mesh.vertices[ia], mesh.vertices[ib], mesh.vertices[ic]
            nx, ny, nz = normal(a, b, c)
            f.write(f"  facet normal {nx:.6g} {ny:.6g} {nz:.6g}\n")
            f.write("    outer loop\n")
            for p in (a, b, c):
                f.write(f"      vertex {p[0]:.6g} {p[1]:.6g} {p[2]:.6g}\n")
            f.write("    endloop\n")
            f.write("  endfacet\n")
        f.write("endsolid brain_section_approx\n")


def write_obj(mesh: Mesh, path: Path) -> None:
    with path.open("w", encoding="ascii") as f:
        f.write("# Approximate neuroanatomical teaching piece\n")
        for x, y, z in mesh.vertices:
            f.write(f"v {x:.6g} {y:.6g} {z:.6g}\n")
        for a, b, c in mesh.faces:
            f.write(f"f {a + 1} {b + 1} {c + 1}\n")


def main() -> None:
    OUT_DIR.mkdir(exist_ok=True)
    mesh = Mesh()
    add_base(mesh)
    add_relief(mesh)
    write_ascii_stl(mesh, STL_PATH)
    write_obj(mesh, OBJ_PATH)
    print(f"Wrote {STL_PATH} with {len(mesh.vertices)} vertices and {len(mesh.faces)} faces")
    print(f"Wrote {OBJ_PATH}")


if __name__ == "__main__":
    main()
