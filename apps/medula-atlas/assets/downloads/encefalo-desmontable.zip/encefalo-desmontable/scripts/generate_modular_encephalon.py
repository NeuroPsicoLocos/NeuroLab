#!/usr/bin/env python3
"""
Generate a simplified disassemblable encephalon set for 3D printing.

The parts are educational approximations based on the provided photos:
- left and right cerebral hemispheres with raised gyri,
- cerebellum with folia-like ridges,
- brainstem with a simple peg for assembly.

The geometry is intentionally clean and editable. It does not reproduce the
original toy/model connectors exactly because the reference photos do not
include caliper measurements or calibrated orthogonal views.
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent))

from generate_brain_section_model import (  # noqa: E402
    Mesh,
    add_cylinder_between,
    add_ellipsoid,
    add_vertical_annular_cylinder,
    write_ascii_stl,
    write_obj,
)


OUT_DIR = Path("models/modular_encephalon")


def write_part(name: str, mesh: Mesh) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    stl = OUT_DIR / f"{name}.stl"
    obj = OUT_DIR / f"{name}.obj"
    write_ascii_stl(mesh, stl)
    write_obj(mesh, obj)
    print(f"Wrote {stl} ({len(mesh.vertices)} vertices, {len(mesh.faces)} faces)")


def add_connector_socket(mesh: Mesh, x: float, y: float, z: float) -> None:
    """Raised ring marking a simplified socket location."""
    add_vertical_annular_cylinder(mesh, (x, y, z), inner_radius=3.1, outer_radius=4.4, height=1.4)


def cerebral_hemisphere(side: str) -> Mesh:
    mesh = Mesh()
    sign = -1 if side == "left" else 1

    # Main hemisphere body, slightly flattened medially.
    add_ellipsoid(mesh, (sign * 18, 0, 18), (33, 47, 18), rot_z=sign * 0.12, lat_steps=18, lon_steps=44)
    add_ellipsoid(mesh, (sign * 9, -19, 13), (20, 25, 11), rot_z=sign * -0.35, lat_steps=12, lon_steps=34)

    # Raised gyri. These are simplified visual folds, not a labeled anatomical map.
    gyri = [
        (7, 23, 14, 4, 2.7, 0.2), (15, 12, 18, 4, 2.8, -0.45),
        (20, -2, 17, 4, 2.8, 0.3), (12, -16, 16, 4, 2.6, -0.2),
        (27, 23, 13, 4, 2.5, 0.8), (33, 6, 16, 4, 2.7, -0.7),
        (29, -12, 14, 4, 2.6, 0.6), (5, -30, 13, 3.5, 2.4, -0.45),
        (2, 2, 16, 4, 2.8, 0.95),
    ]
    for x, y, rx, ry, rz, rot in gyri:
        add_ellipsoid(mesh, (sign * x, y, 35 + 3 * math.sin(y * 0.08)), (rx, ry, rz), sign * rot)

    # Medial alignment sockets/pins are symbolic and should be adjusted after test fitting.
    add_connector_socket(mesh, sign * 2.5, 9, 16)
    add_connector_socket(mesh, sign * 3.0, -17, 13)

    # Small inferior peg to relate the hemisphere to brainstem/cerebellum.
    add_cylinder_between(mesh, (sign * 14, -37, 9), (sign * 14, -49, 9), 2.8, 24)
    return mesh


def cerebellum() -> Mesh:
    mesh = Mesh()
    add_ellipsoid(mesh, (-15, 0, 12), (20, 18, 11), rot_z=0.15, lat_steps=14, lon_steps=38)
    add_ellipsoid(mesh, (15, 0, 12), (20, 18, 11), rot_z=-0.15, lat_steps=14, lon_steps=38)
    add_ellipsoid(mesh, (0, -3, 10), (13, 15, 9), rot_z=0, lat_steps=12, lon_steps=32)

    # Folia-like ridges across the posterior surface.
    for i in range(18):
        y = -16 + i * 1.9
        z = 22 - 0.025 * y * y
        add_cylinder_between(mesh, (-31, y, z), (31, y, z + 0.8 * math.sin(i)), 0.45, 10)

    add_connector_socket(mesh, 0, 18, 13)
    return mesh


def brainstem() -> Mesh:
    mesh = Mesh()
    add_ellipsoid(mesh, (0, 11, 23), (9, 8, 10), rot_z=0, lat_steps=12, lon_steps=28)
    add_ellipsoid(mesh, (0, 1, 15), (8, 7, 10), rot_z=0, lat_steps=12, lon_steps=28)
    add_cylinder_between(mesh, (0, -3, 3), (0, -3, 18), 6.1, 32)
    add_cylinder_between(mesh, (-3.8, -3, -14), (-3.8, -3, 4), 3.0, 24)
    add_cylinder_between(mesh, (3.8, -3, -14), (3.8, -3, 4), 3.0, 24)

    # Assembly pegs toward cerebrum/cerebellum.
    add_cylinder_between(mesh, (0, 17, 25), (0, 28, 25), 2.8, 24)
    add_cylinder_between(mesh, (0, -10, 13), (0, -23, 13), 2.8, 24)
    return mesh


def vascular_arch() -> Mesh:
    mesh = Mesh()
    # Very simplified transparent-vessel-like arch seen in the photos.
    for x in (-12, 12):
        add_cylinder_between(mesh, (x, -24, 2), (x * 0.45, -4, 8), 1.25, 16)
        add_cylinder_between(mesh, (x * 0.45, -4, 8), (x * 0.25, 13, 9), 1.05, 16)
    add_cylinder_between(mesh, (-5, 12, 9), (5, 12, 9), 1.2, 16)
    add_cylinder_between(mesh, (-11, -9, 7), (-23, -1, 7), 0.9, 14)
    add_cylinder_between(mesh, (11, -9, 7), (23, -1, 7), 0.9, 14)
    return mesh


def main() -> None:
    parts = {
        "left_cerebral_hemisphere": cerebral_hemisphere("left"),
        "right_cerebral_hemisphere": cerebral_hemisphere("right"),
        "cerebellum": cerebellum(),
        "brainstem": brainstem(),
        "vascular_arch_simplified": vascular_arch(),
    }
    for name, mesh in parts.items():
        write_part(name, mesh)


if __name__ == "__main__":
    main()
